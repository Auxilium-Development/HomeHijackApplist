#import <Preferences/PSListController.h>

@interface HHIRootListController : PSListController

@end
